# StereoGuide v0.6.0 – 3D Stereo Kamera

Samsung ve diğer Android telefonlarda iki çekimden Quest 3 uyumlu yan yana
(SBS) 3D fotoğraf üretir.

## Çekim akışı

1. Kullanıcı ilk fotoğraf için deklanşöre bir kez basar.
2. Ekranda büyük ve açık bir sağa kaydırma oku görünür.
3. Kullanıcı telefonu tek hareketle biraz sağa kaydırır.
4. Uygulama canlı görüntüyü ilk kareyle karşılaştırır.
5. Yeterli sağa hareket algılanır algılanmaz ikinci kare otomatik çekilir.
6. Uygulama iki karedeki yatay/dikey kaymayı ve dönüşü otomatik düzeltir.
7. İki kare 16:9 SBS görüntü olarak birleştirilip galeriye kaydedilir.

## APK indirme

GitHub'da `Actions` sekmesini açın. En yeni başarılı `Build Android APK`
çalışmasına dokunun ve `Artifacts` bölümündeki `StereoGuide-debug-apk`
dosyasını indirin. ZIP'i açtıktan sonra içindeki `app-debug.apk` dosyasını
Android telefona kurabilirsiniz.

## v0.6.0 yenilikleri

- İkinci çekim tetiklenince kırmızı STOP ve “SABİT TUT” uyarısı gösterilir.
- Çekim tamamlanınca yeşil onay işareti görünür.
- Dönüş ve kayma iki gerçek fotoğrafın ortak ayrıntılarından hesaplanır.
- Döndürme sonrası siyah üçgenler iki kareden eşit alan kırpılarak kaldırılır.
- Birleşik çıktı en fazla 3840×2160 ve tam 16:9 oranında kaydedilir.
- Özel StereoGuide uygulama ikonu eklenmiştir.
- Sabit imza sayesinde v0.6.0 sonrası APK’lar birbirinin üzerine kurulabilir.

v0.5.0 geçici bir anahtarla imzalandığı için v0.6.0 kurulurken eski sürümün
bir kez kaldırılması gerekir. Paketteki anahtar yalnızca kişisel dağıtım içindir.

## Teknik bilgiler

- Android 8.0 veya üzeri (`minSdk 26`)
- CameraX kamera önizleme, çekim ve canlı kare analizi
- Telefon açısı için hareket sensörleri
- Çıktı klasörü: `Pictures/StereoGuide`

Samsung/Android telefonlarla Meta Quest 3 için doğru side-by-side (SBS) 3D
fotoğraf çekmeye yardımcı olan CameraX tabanlı bir Android uygulaması.

## Özellikler

- Kullanıcıdan manuel fotoğraf hizalaması istemez.
- Canlı kamera karelerini ilk kareyle karşılaştırarak sağ-sol ve dikey sapmayı
  ölçer.
- Görüntü doğrulamasını 96×160 gri karelerde kaba→ince aramayla yaptığı için
  kamera önizlemesini ve deklanşörü gereksiz yere yavaşlatmaz.
- Jiroskop/rotation-vector sensörüyle dönüş farkını ölçer ve çekimden sonra düzeltir.
- Tek bir büyük sağa kaydırma oku kullanır; tilt, çekimi engellemez.
- Hedef sağa hareket ilk güvenilir canlı karede algılanır algılanmaz ikinci
  fotoğrafı zamanlayıcısız çeker.
- İki kareyi ölçülen yatay/dikey görüntü kaymasına göre otomatik kırpar ve hizalar.
- Alt panel Android gezinme çubuğunun yüksekliğine göre otomatik yukarı taşınır.
- Hareketli öznelerde iki çekim arasını kısaltmak için CameraX düşük gecikmeli
  çekim modunu kullanır.
- Yakın, portre ve uzak sahneler için 4/6/8 cm taban mesafesi önerir.
- İki çekimi otomatik olarak 16:9 SBS JPEG biçiminde birleştirir.
- Sonucu `Pictures/StereoGuide` klasörüne kaydeder.
- Sol panel ilk, sağ panel ikinci çekimdir; Quest uygulamasında `3D SBS / Flat`
  seçilmelidir.

## Android Studio ile APK oluşturma

1. Android Studio’da bu klasörü açın.
2. Android SDK 35’in kurulu olduğundan emin olun.
3. Gradle eşitlemesini tamamlayın.
4. `Build > Build APK(s)` seçin.
5. APK `app/build/outputs/apk/debug/app-debug.apk` altında oluşur.

## Çekim

1. Sahne mesafesini seçin.
2. İlk kareyi çekin.
3. Telefonu büyük oku izleyerek tek hareketle sağa kaydırın.
4. Telefon yeterince sağa ulaşır ulaşmaz ikinci kare otomatik çekilir;
   ayrıca beklemeniz veya yeniden deklanşöre basmanız gerekmez.
5. SBS fotoğraf Galeri’ye kaydedilir.

## MVP sınırı

Bu sürüm yatay hareketi ve son hizalamayı canlı görüntü eşleştirmesiyle yaklaşık olarak ölçer.
4/6/8 cm seçenekleri, yakın/portre/uzak sahne için hedef görüntü kaymasını
ayarlar. Ölçüm sahnedeki ayrıntı ve ışığa bağlıdır; tamamen dokusuz duvarda
referans noktası bulunamayabilir. Mutlak santimetre ölçümü için ARCore Shared
Camera gerekir.
