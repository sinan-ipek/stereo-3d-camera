package com.stereoguide.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

object StereoComposer {
    private data class Transform(val angle: Float, val tx: Float, val ty: Float, val score: Double)

    fun decode(file: File): Bitmap {
        val source = BitmapFactory.decodeFile(file.absolutePath) ?: error("Fotoğraf okunamadı")
        val orientation = ExifInterface(file).getAttributeInt(
            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
        )
        val rotation = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (rotation == 0f) return source
        val corrected = Bitmap.createBitmap(
            source, 0, 0, source.width, source.height,
            Matrix().apply { postRotate(rotation) }, true
        )
        source.recycle()
        return corrected
    }

    /**
     * Gerçek fotoğraf ayrıntılarını karşılaştırarak sağ kareyi sola kaydeder ve
     * döndürür. Sensör açısı yalnızca görüntü çok dokusuzsa yedek başlangıçtır.
     */
    fun makeSbs16x9(leftFile: File, rightFile: File, sensorRollDifference: Float): Bitmap {
        var left = decode(leftFile)
        var right = decode(rightFile)
        val commonW = min(left.width, right.width)
        val commonH = min(left.height, right.height)
        left = centerCrop(left, commonW, commonH)
        right = centerCrop(right, commonW, commonH)

        val transform = estimateTransform(left, right, sensorRollDifference)
        val alignedRight = Bitmap.createBitmap(commonW, commonH, Bitmap.Config.ARGB_8888)
        Canvas(alignedRight).apply {
            drawColor(Color.BLACK)
            val matrix = Matrix().apply {
                postRotate(transform.angle, commonW / 2f, commonH / 2f)
                postTranslate(transform.tx, transform.ty)
            }
            drawBitmap(right, matrix, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        }

        // Dönüşten kalan üçgenlerin hiçbirinin çıktıya girmeyeceği ortak güvenli alan.
        val radians = Math.toRadians(abs(transform.angle).toDouble())
        val marginX = ceil(commonH * sin(radians) + abs(transform.tx) + 8).toInt()
        val marginY = ceil(commonW * sin(radians) + abs(transform.ty) + 8).toInt()
        val safeW = (commonW - marginX * 2).coerceAtLeast(640)
        val safeH = (commonH - marginY * 2).coerceAtLeast(720)
        val panelW = min(safeW, (safeH * 8f / 9f).roundToInt())
        val panelH = (panelW * 9f / 8f).roundToInt()
        val cropX = (commonW - panelW) / 2
        val cropY = (commonH - panelH) / 2

        // Bellek kullanımını sınırlarken birleşik çıktıyı en fazla 4K tut.
        val outPanelW = min(panelW, 1920)
        val outPanelH = (outPanelW * 9f / 8f).roundToInt()
        val output = Bitmap.createBitmap(outPanelW * 2, outPanelH, Bitmap.Config.ARGB_8888)
        val src = Rect(cropX, cropY, cropX + panelW, cropY + panelH)
        val dstLeft = Rect(0, 0, outPanelW, outPanelH)
        val dstRight = Rect(outPanelW, 0, outPanelW * 2, outPanelH)
        Canvas(output).apply {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            drawBitmap(left, src, dstLeft, paint)
            drawBitmap(alignedRight, src, dstRight, paint)
        }
        left.recycle()
        right.recycle()
        alignedRight.recycle()
        return output
    }

    private fun centerCrop(source: Bitmap, width: Int, height: Int): Bitmap {
        if (source.width == width && source.height == height) return source
        val cropped = Bitmap.createBitmap(
            source, (source.width - width) / 2, (source.height - height) / 2, width, height
        )
        source.recycle()
        return cropped
    }

    private fun estimateTransform(left: Bitmap, right: Bitmap, sensorRoll: Float): Transform {
        val sampleH = 240
        val sampleW = max(120, (left.width * sampleH.toFloat() / left.height).roundToInt())
        val l = grayscale(Bitmap.createScaledBitmap(left, sampleW, sampleH, true))
        val r = grayscale(Bitmap.createScaledBitmap(right, sampleW, sampleH, true))
        val sensorHint = (-sensorRoll).coerceIn(-5f, 5f)

        var best = Transform(sensorHint, 0f, 0f, Double.MAX_VALUE)
        val coarseAngles = mutableListOf<Float>()
        var a = -5f
        while (a <= 5.001f) { coarseAngles += a; a += .5f }
        for (angle in coarseAngles) {
            for (ty in -16..16 step 2) {
                for (tx in -34..34 step 2) {
                    val score = scoreTransform(l, r, sampleW, sampleH, angle, tx.toFloat(), ty.toFloat(), 4)
                    if (score < best.score) best = Transform(angle, tx.toFloat(), ty.toFloat(), score)
                }
            }
        }

        val coarse = best
        var fineAngle = coarse.angle - .5f
        while (fineAngle <= coarse.angle + .501f) {
            for (ty in (coarse.ty.toInt() - 2)..(coarse.ty.toInt() + 2)) {
                for (tx in (coarse.tx.toInt() - 2)..(coarse.tx.toInt() + 2)) {
                    val score = scoreTransform(l, r, sampleW, sampleH, fineAngle, tx.toFloat(), ty.toFloat(), 2)
                    if (score < best.score) best = Transform(fineAngle, tx.toFloat(), ty.toFloat(), score)
                }
            }
            fineAngle += .1f
        }
        return Transform(
            best.angle,
            best.tx * left.width / sampleW,
            best.ty * left.height / sampleH,
            best.score
        )
    }

    private fun grayscale(bitmap: Bitmap): IntArray {
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        for (i in pixels.indices) {
            val c = pixels[i]
            pixels[i] = ((Color.red(c) * 77 + Color.green(c) * 150 + Color.blue(c) * 29) shr 8)
        }
        bitmap.recycle()
        return pixels
    }

    private fun scoreTransform(
        left: IntArray, right: IntArray, w: Int, h: Int,
        angle: Float, tx: Float, ty: Float, step: Int
    ): Double {
        val rad = Math.toRadians(angle.toDouble())
        val cos = kotlin.math.cos(rad)
        val sin = kotlin.math.sin(rad)
        val cx = w / 2.0
        val cy = h / 2.0
        var total = 0.0
        var samples = 0
        // Kenarlar ve çok yakın ön plan yerine geniş merkez bölgeyi kullan.
        var y = 28
        while (y < h - 28) {
            var x = 18
            while (x < w - 18) {
                // Uygulanan dönüşümün tersinden sağ görüntü koordinatını bul.
                val ox = x - tx - cx
                val oy = y - ty - cy
                val sx = (cos * ox + sin * oy + cx).roundToInt()
                val sy = (-sin * ox + cos * oy + cy).roundToInt()
                if (sx in 1 until w - 1 && sy in 1 until h - 1) {
                    val li = y * w + x
                    val ri = sy * w + sx
                    val lGradient = abs(left[li + 1] - left[li - 1]) + abs(left[li + w] - left[li - w])
                    val rGradient = abs(right[ri + 1] - right[ri - 1]) + abs(right[ri + w] - right[ri - w])
                    val weight = 1.0 + min(160, lGradient + rGradient) / 50.0
                    total += abs(left[li] - right[ri]) * weight
                    samples++
                }
                x += step
            }
            y += step
        }
        return if (samples == 0) Double.MAX_VALUE else total / samples
    }

    fun save(context: Context, bitmap: Bitmap): Uri {
        val name = "StereoGuide_${System.currentTimeMillis()}_SBS.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/StereoGuide")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Galeri kaydı oluşturulamadı")
        context.contentResolver.openOutputStream(uri).use {
            checkNotNull(it)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 96, it)
        }
        return uri
    }
}
