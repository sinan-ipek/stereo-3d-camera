package com.stereoguide.app

import android.graphics.Bitmap
import android.graphics.Color
import java.io.File
import kotlin.math.abs

/** Üçer karelik iki kısa seriden hareket farkı en az olan stereo çiftini seçer. */
object BurstPairSelector {
    private const val WIDTH = 160
    private const val HEIGHT = 90

    fun select(leftFiles: List<File>, rightFiles: List<File>): Pair<File, File> {
        require(leftFiles.isNotEmpty() && rightFiles.isNotEmpty())
        val leftSamples = leftFiles.map(::sample)
        val rightSamples = rightFiles.map(::sample)
        var bestLeft = 0
        var bestRight = 0
        var bestScore = Long.MAX_VALUE

        for (leftIndex in leftSamples.indices) {
            for (rightIndex in rightSamples.indices) {
                val score = alignedDifference(leftSamples[leftIndex], rightSamples[rightIndex])
                if (score < bestScore) {
                    bestScore = score
                    bestLeft = leftIndex
                    bestRight = rightIndex
                }
            }
        }
        return leftFiles[bestLeft] to rightFiles[bestRight]
    }

    private fun sample(file: File): IntArray {
        val source = StereoComposer.decode(file)
        val scaled = Bitmap.createScaledBitmap(source, WIDTH, HEIGHT, true)
        if (scaled !== source) source.recycle()
        val pixels = IntArray(WIDTH * HEIGHT)
        scaled.getPixels(pixels, 0, WIDTH, 0, 0, WIDTH, HEIGHT)
        scaled.recycle()
        for (i in pixels.indices) {
            val color = pixels[i]
            pixels[i] = (Color.red(color) * 77 + Color.green(color) * 150 +
                Color.blue(color) * 29) shr 8
        }
        return pixels
    }

    private fun alignedDifference(left: IntArray, right: IntArray): Long {
        var best = Long.MAX_VALUE
        // Kamera kaymasıyla oluşan genel stereo yer değiştirmesini önce yok say;
        // geriye kalan fark ağırlıklı olarak gerçek sahne hareketidir.
        for (dy in -8..8 step 2) {
            for (dx in -28..28 step 2) {
                var total = 0L
                var count = 0
                var y = 12
                while (y < HEIGHT - 12) {
                    var x = 18
                    while (x < WIDTH - 18) {
                        val rx = x + dx
                        val ry = y + dy
                        if (rx in 0 until WIDTH && ry in 0 until HEIGHT) {
                            total += abs(left[y * WIDTH + x] - right[ry * WIDTH + rx])
                            count++
                        }
                        x += 3
                    }
                    y += 3
                }
                if (count > 0) best = minOf(best, total / count)
            }
        }
        return best
    }
}
