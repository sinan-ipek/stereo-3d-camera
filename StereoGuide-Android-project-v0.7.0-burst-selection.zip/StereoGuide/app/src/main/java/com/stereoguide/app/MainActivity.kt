package com.stereoguide.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.stereoguide.app.databinding.ActivityMainBinding
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var executor: ExecutorService
    private lateinit var tracker: OrientationTracker
    private lateinit var analyzer: FrameAlignmentAnalyzer
    private var imageCapture: ImageCapture? = null
    private val firstBurst = mutableListOf<File>()
    private var firstPitch = 0f
    private var firstRoll = 0f
    private var pitch = 0f
    private var roll = 0f
    private var targetCm = 6
    private var targetShiftPixels = 7
    private var currentHorizontalError = 1f
    private var lastAlignmentDx = 0
    private var lastAlignmentDy = 0
    private var automaticCaptureRunning = false

    private val permission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else Toast.makeText(this, R.string.camera_permission, Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.controls) { view, insets ->
            val bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            view.setPadding(view.paddingLeft, view.paddingTop, view.paddingRight, bottom + dp(12))
            insets
        }
        executor = Executors.newSingleThreadExecutor()
        analyzer = FrameAlignmentAnalyzer { dx, dy ->
            runOnUiThread { updateVisualAlignment(dx, dy) }
        }

        tracker = OrientationTracker(this) { p, r ->
            pitch = p
            roll = r
            runOnUiThread {
                if (firstBurst.isNotEmpty()) {
                    binding.guide.pitchDelta = pitch - firstPitch
                    binding.guide.rollDelta = roll - firstRoll
                }
            }
        }

        binding.distanceGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked || firstBurst.isNotEmpty()) return@addOnButtonCheckedListener
            targetCm = when (checkedId) {
                R.id.close -> 4
                R.id.landscape -> 8
                else -> 6
            }
            targetShiftPixels = when (checkedId) {
                R.id.close -> 10
                R.id.landscape -> 5
                else -> 7
            }
        }
        binding.shutter.setOnClickListener { capture() }
        binding.reset.setOnClickListener { reset() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) startCamera() else permission.launch(Manifest.permission.CAMERA)
    }

    override fun onResume() {
        super.onResume()
        tracker.start()
    }

    override fun onPause() {
        tracker.stop()
        super.onPause()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder()
                .setTargetAspectRatio(androidx.camera.core.AspectRatio.RATIO_16_9)
                .build().also { it.surfaceProvider = binding.preview.surfaceProvider }
            imageCapture = ImageCapture.Builder()
                // Hareketli öznelerde iki çekim arasını mümkün olduğunca kısalt.
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setTargetAspectRatio(androidx.camera.core.AspectRatio.RATIO_16_9)
                .build()
            val analysis = ImageAnalysis.Builder()
                .setTargetAspectRatio(androidx.camera.core.AspectRatio.RATIO_16_9)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build().also { it.setAnalyzer(executor, analyzer) }
            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                imageCapture,
                analysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun capture() {
        if (firstBurst.isNotEmpty() && !automaticCaptureRunning) return
        binding.shutter.isEnabled = false
        captureBurst(3, mutableListOf()) { files, error ->
            runOnUiThread {
                binding.shutter.isEnabled = true
                if (error != null) {
                    files.forEach(File::delete)
                    Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()
                    if (firstBurst.isNotEmpty()) reset()
                } else if (firstBurst.isEmpty()) {
                    acceptFirst(files)
                } else {
                    acceptSecond(files)
                }
            }
        }
    }

    private fun captureBurst(
        remaining: Int,
        files: MutableList<File>,
        done: (List<File>, ImageCaptureException?) -> Unit
    ) {
        val capture = imageCapture
        if (capture == null) {
            done(files, null)
            return
        }
        val file = File.createTempFile("stereo_burst_", ".jpg", cacheDir)
        val output = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(output, executor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                files += file
                if (remaining > 1) captureBurst(remaining - 1, files, done)
                else done(files, null)
            }

            override fun onError(exception: ImageCaptureException) {
                file.delete()
                done(files, exception)
            }
        })
    }

    private fun acceptFirst(files: List<File>) {
        firstBurst += files
        firstPitch = pitch
        firstRoll = roll
        analyzer.requestReference()
        // Kullanıcıdan manuel üst üste bindirme beklemiyoruz. Canlı analiz ve
        // sonradan kırpma/döndürme işlemlerini uygulama yapar.
        binding.ghost.visibility = android.view.View.GONE
        binding.guide.secondShot = true
        binding.distanceGroup.isEnabled = false
        binding.shutter.visibility = android.view.View.INVISIBLE
        binding.status.text = getString(R.string.second_photo, targetCm)
        vibrate()
    }

    private fun acceptSecond(secondBurst: List<File>) {
        binding.guide.holdStill = false
        binding.guide.captured = true
        binding.status.setText(R.string.processing)
        executor.execute {
            try {
                val pair = BurstPairSelector.select(firstBurst, secondBurst)
                val sbs = StereoComposer.makeSbs16x9(pair.first, pair.second, roll - firstRoll)
                StereoComposer.save(this, sbs)
                sbs.recycle()
                runOnUiThread {
                    Toast.makeText(this, R.string.saved, Toast.LENGTH_LONG).show()
                    vibrate()
                    binding.root.postDelayed({ reset() }, 450)
                }
            } catch (error: Throwable) {
                runOnUiThread {
                    Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()
                    reset()
                }
            } finally {
                firstBurst.forEach(File::delete)
                secondBurst.forEach(File::delete)
            }
        }
    }

    private fun reset() {
        firstBurst.forEach(File::delete)
        firstBurst.clear()
        analyzer.clearReference()
        automaticCaptureRunning = false
        lastAlignmentDx = 0
        lastAlignmentDy = 0
        currentHorizontalError = 1f
        binding.ghost.setImageDrawable(null)
        binding.ghost.visibility = android.view.View.GONE
        binding.guide.secondShot = false
        binding.guide.holdStill = false
        binding.guide.captured = false
        binding.guide.pitchDelta = 0f
        binding.guide.rollDelta = 0f
        binding.guide.horizontalError = 1f
        binding.guide.verticalError = 0f
        binding.guide.stabilityProgress = 0f
        binding.distanceGroup.isEnabled = true
        binding.shutter.visibility = android.view.View.VISIBLE
        binding.shutter.isEnabled = true
        binding.status.setText(R.string.first_photo)
    }

    private fun updateVisualAlignment(dx: Int, dy: Int) {
        if (firstBurst.isEmpty() || automaticCaptureRunning) return
        // Telefon sağa giderken sahne canlı karede sola kayar; bu yüzden hedef negatiftir.
        val targetDx = -targetShiftPixels
        currentHorizontalError = (dx - targetDx).toFloat() / targetShiftPixels
        lastAlignmentDx = dx
        lastAlignmentDy = dy
        binding.guide.horizontalError = currentHorizontalError
        binding.guide.verticalError = dy / 10f

        // Sağa doğru yeterli hareket gerçekleşir gerçekleşmez çek. Tilt ve
        // dikey sapma kullanıcıyı bekletmez; besteci bunları sonradan düzeltir.
        val reached = dx <= targetDx + 2
        if (!reached) {
            binding.guide.stabilityProgress = 0f
            binding.status.setText(
                if (currentHorizontalError > 0f) R.string.move_right else R.string.move_left
            )
            return
        }

        binding.guide.stabilityProgress = 1f
        binding.guide.holdStill = true
        binding.status.setText(R.string.hold_still)
        automaticCaptureRunning = true
        vibrate()
        capture()
    }

    private fun vibrate() {
        getSystemService<Vibrator>()?.vibrate(
            VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE)
        )
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
