# StereoGuide

Samsung/Android telefonlarla Meta Quest 3 için doğru side-by-side (SBS) 3D
fotoğraf çekmeye yardımcı olan CameraX tabanlı bir Android uygulaması.

## Özellikler

- İlk fotoğrafı yarı saydam bir hizalama katmanı olarak gösterir.
- Canlı kamera karelerini ilk kareyle karşılaştırarak sağ-sol ve dikey sapmayı
  ölçer.
- Görüntü doğrulamasını 96×160 gri karelerde kaba→ince aramayla yaptığı için
  kamera önizlemesini ve deklanşörü gereksiz yere yavaşlatmaz.
- Jiroskop/rotation-vector sensörüyle tilt ve dönüş farkını gösterir.
- Sağ-sol ve tilt oklarıyla kullanıcıyı doğru ikinci konuma yönlendirir.
- Hedef bölge iki ardışık canlı karede doğrulanır doğrulanmaz, zamanlayıcıyla
  beklemeden ikinci fotoğrafı otomatik çeker.
- Hareketli öznelerde iki çekim arasını kısaltmak için CameraX düşük gecikmeli
  çekim modunu kullanır.
- Yakın, portre ve uzak sahneler için 4/6/8 cm taban mesafesi önerir.
- İki çekimi otomatik olarak 16:9 SBS JPEG biçiminde birleştirir.
- Sonucu `Pictures/StereoGuide` klasörüne kaydeder.
- Sol panel ilk, sağ panel ikinci çekimdir; Quest uygulamasında `3D SBS / Flat`
  seçilmelidir.

## Android Studio ile APK oluşturma

1. Android Studio’da bu klasörü açın.
2. Android SDK 35’in kurulu olduğundan emin olun.
3. Gradle eşitlemesini tamamlayın.
4. `Build > Build APK(s)` seçin.
5. APK `app/build/outputs/apk/debug/app-debug.apk` altında oluşur.

## Çekim

1. Sahne mesafesini seçin.
2. İlk kareyi çekin.
3. Telefonu okları izleyerek sağa kaydırın; hayalet görüntüyü referans alın.
4. Telefon yaklaşık doğru konuma ulaşır ulaşmaz ikinci kare otomatik çekilir;
   ayrıca beklemeniz veya yeniden deklanşöre basmanız gerekmez.
5. SBS fotoğraf Galeri’ye kaydedilir.

## MVP sınırı

Bu sürüm yatay hareketi canlı görüntü eşleştirmesiyle yaklaşık olarak ölçer.
4/6/8 cm seçenekleri, yakın/portre/uzak sahne için hedef görüntü kaymasını
ayarlar. Ölçüm sahnedeki ayrıntı ve ışığa bağlıdır; tamamen dokusuz duvarda
referans noktası bulunamayabilir. Mutlak santimetre ölçümü için ARCore Shared
Camera gerekir.
