package com.stereoguide.app

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import kotlin.math.abs

class FrameAlignmentAnalyzer(
    private val onAlignment: (horizontalPixels: Int, verticalPixels: Int) -> Unit
) : ImageAnalysis.Analyzer {
    private val outW = 96
    private val outH = 160
    @Volatile private var reference: ByteArray? = null
    @Volatile private var captureReference = false
    private val recentDx = ArrayDeque<Int>()
    private val recentDy = ArrayDeque<Int>()

    fun requestReference() {
        captureReference = true
    }

    fun clearReference() {
        reference = null
        captureReference = false
        recentDx.clear()
        recentDy.clear()
    }

    override fun analyze(image: ImageProxy) {
        try {
            val gray = downsamplePortrait(image)
            if (captureReference) {
                reference = gray
                captureReference = false
                return
            }
            val ref = reference ?: return
            val (dx, dy) = bestTranslation(ref, gray)
            recentDx.addLast(dx)
            recentDy.addLast(dy)
            // Üç karelik medyan, beş kareye göre daha hızlı tepki verirken
            // tek karelik görüntü gürültüsünü hâlâ süzer.
            if (recentDx.size > 3) recentDx.removeFirst()
            if (recentDy.size > 3) recentDy.removeFirst()
            onAlignment(median(recentDx), median(recentDy))
        } finally {
            image.close()
        }
    }

    private fun median(values: ArrayDeque<Int>): Int {
        val sorted = values.sorted()
        return sorted[sorted.size / 2]
    }

    private fun downsamplePortrait(image: ImageProxy): ByteArray {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val sourceW = image.width
        val sourceH = image.height
        val rotation = image.imageInfo.rotationDegrees
        val output = ByteArray(outW * outH)

        for (oy in 0 until outH) {
            for (ox in 0 until outW) {
                val nx = ox.toFloat() / outW
                val ny = oy.toFloat() / outH
                val (sx, sy) = when (rotation) {
                    90 -> Pair(
                        (ny * sourceW).toInt(),
                        ((1f - nx) * sourceH).toInt()
                    )
                    270 -> Pair(
                        ((1f - ny) * sourceW).toInt(),
                        (nx * sourceH).toInt()
                    )
                    180 -> Pair(
                        ((1f - nx) * sourceW).toInt(),
                        ((1f - ny) * sourceH).toInt()
                    )
                    else -> Pair(
                        (nx * sourceW).toInt(),
                        (ny * sourceH).toInt()
                    )
                }
                val x = sx.coerceIn(0, sourceW - 1)
                val y = sy.coerceIn(0, sourceH - 1)
                output[oy * outW + ox] = buffer.get(y * rowStride + x * pixelStride)
            }
        }
        return output
    }

    private fun bestTranslation(reference: ByteArray, current: ByteArray): Pair<Int, Int> {
        // İki aşamalı arama, bütün alanı her karede ayrıntılı taramaktan çok
        // daha hafiftir. Önce 2 piksellik adımlarla kaba konumu bulur, sonra
        // yalnızca o noktanın yakınını tam piksel hassasiyetinde kontrol eder.
        var bestDx = 0
        var bestDy = 0
        var bestScore = Long.MAX_VALUE
        for (dy in -10..10 step 2) {
            for (dx in -18..18 step 2) {
                val score = translationScore(reference, current, dx, dy, 3)
                if (score < bestScore) {
                    bestScore = score
                    bestDx = dx
                    bestDy = dy
                }
            }
        }

        val coarseDx = bestDx
        val coarseDy = bestDy
        bestScore = Long.MAX_VALUE
        for (dy in (coarseDy - 2)..(coarseDy + 2)) {
            for (dx in (coarseDx - 2)..(coarseDx + 2)) {
                if (dx !in -18..18 || dy !in -10..10) continue
                val score = translationScore(reference, current, dx, dy, 2)
                if (score < bestScore) {
                    bestScore = score
                    bestDx = dx
                    bestDy = dy
                }
            }
        }
        return Pair(bestDx, bestDy)
    }

    private fun translationScore(
        reference: ByteArray,
        current: ByteArray,
        dx: Int,
        dy: Int,
        sampleStep: Int
    ): Long {
        val marginX = 20
        val marginY = 14
        var score = 0L
        var samples = 0
        var y = marginY
        while (y < outH - marginY) {
            var x = marginX
            while (x < outW - marginX) {
                val cx = x + dx
                val cy = y + dy
                if (cx in 0 until outW && cy in 0 until outH) {
                    val a = reference[y * outW + x].toInt() and 0xff
                    val b = current[cy * outW + cx].toInt() and 0xff
                    score += abs(a - b)
                    samples++
                }
                x += sampleStep
            }
            y += sampleStep
        }
        return if (samples == 0) Long.MAX_VALUE else score / samples
    }
}
