package com.stereoguide.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

class GuideOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = resources.displayMetrics.density * 2f
        style = Paint.Style.STROKE
    }
    var rollDelta = 0f
        set(value) { field = value; invalidate() }
    var pitchDelta = 0f
        set(value) { field = value; invalidate() }
    var horizontalError = 1f
        set(value) { field = value; invalidate() }
    var verticalError = 0f
        set(value) { field = value; invalidate() }
    var stabilityProgress = 0f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }
    var secondShot = false
        set(value) { field = value; invalidate() }

    val isLevel: Boolean
        get() = abs(rollDelta) < 1.3f &&
            abs(pitchDelta) < 1.3f &&
            abs(verticalError) < .12f

    val isInCaptureZone: Boolean
        get() = secondShot && isLevel && abs(horizontalError) < .13f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        paint.color = if (!secondShot || isLevel) Color.rgb(53, 208, 127) else Color.rgb(255, 138, 0)
        canvas.drawLine(cx - 90f, cy, cx + 90f, cy, paint)
        canvas.drawLine(cx, cy - 90f, cx, cy + 90f, paint)
        canvas.drawCircle(cx, cy, 34f, paint)
        if (secondShot) {
            drawMovementArrow(canvas)
            drawTiltArrows(canvas)
            paint.strokeWidth = resources.displayMetrics.density * 7f
            paint.color = Color.argb(210, 255, 255, 255)
            canvas.drawArc(
                cx - 52f, cy - 52f, cx + 52f, cy + 52f,
                -90f, 360f * stabilityProgress, false, paint
            )
            paint.strokeWidth = resources.displayMetrics.density * 2f
        }
    }

    private fun drawMovementArrow(canvas: Canvas) {
        val cy = height * .76f
        val goRight = horizontalError > 0f
        val start = if (goRight) width * .24f else width * .76f
        val end = if (goRight) width * .76f else width * .24f
        paint.color = if (abs(horizontalError) < .13f) {
            Color.rgb(53, 208, 127)
        } else {
            Color.rgb(255, 138, 0)
        }
        paint.strokeWidth = resources.displayMetrics.density * 8f
        canvas.drawLine(start, cy, end, cy, paint)
        val direction = if (goRight) 1f else -1f
        val path = Path().apply {
            moveTo(end, cy)
            lineTo(end - direction * 34f, cy - 28f)
            lineTo(end - direction * 34f, cy + 28f)
            close()
        }
        paint.style = Paint.Style.FILL
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.STROKE
    }

    private fun drawTiltArrows(canvas: Canvas) {
        if (abs(rollDelta) < 1.3f && abs(pitchDelta) < 1.3f && abs(verticalError) < .12f) return
        paint.color = Color.rgb(255, 138, 0)
        paint.strokeWidth = resources.displayMetrics.density * 4f
        val x = width * .88f
        val centerY = height * .42f
        val direction = if (pitchDelta + verticalError * 4f > 0f) -1f else 1f
        canvas.drawLine(x, centerY, x, centerY + direction * 90f, paint)
        canvas.drawLine(
            x, centerY + direction * 90f,
            x - 20f, centerY + direction * 65f, paint
        )
        canvas.drawLine(
            x, centerY + direction * 90f,
            x + 20f, centerY + direction * 65f, paint
        )
    }
}
