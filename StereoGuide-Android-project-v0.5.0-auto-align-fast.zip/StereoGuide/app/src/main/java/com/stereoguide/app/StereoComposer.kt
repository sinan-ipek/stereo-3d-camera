package com.stereoguide.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

object StereoComposer {
    fun decode(file: File): Bitmap {
        val source = BitmapFactory.decodeFile(file.absolutePath)
            ?: error("Fotoğraf okunamadı")
        val orientation = ExifInterface(file).getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL
        )
        val rotation = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (rotation == 0f) return source
        val matrix = Matrix().apply { postRotate(rotation) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    fun makeSbs16x9(
        leftFile: File,
        rightFile: File,
        rollDifference: Float,
        alignmentDx: Int,
        alignmentDy: Int,
        analysisWidth: Int,
        analysisHeight: Int
    ): Bitmap {
        val left = decode(leftFile)
        var right = decode(rightFile)
        if (abs(rollDifference) > .05f) {
            val m = Matrix().apply { postRotate(-rollDifference) }
            right = Bitmap.createBitmap(right, 0, 0, right.width, right.height, m, true)
        }

        val dxPx = (alignmentDx * right.width.toFloat() / analysisWidth).roundToInt()
        val dyPx = (alignmentDy * right.height.toFloat() / analysisHeight).roundToInt()
        val safeW = minOf(left.width, right.width) - abs(dxPx)
        val safeH = minOf(left.height, right.height) - abs(dyPx)
        val panelW = minOf(safeW, (safeH * 8f / 9f).roundToInt()).coerceAtLeast(320)
        val panelH = (panelW * 9f / 8f).roundToInt()

        val baseLX = ((left.width - panelW) / 2).coerceAtLeast(0)
        val baseLY = ((left.height - panelH) / 2).coerceAtLeast(0)
        val baseRX = (baseLX + dxPx).coerceIn(0, right.width - panelW)
        val baseRY = (baseLY + dyPx).coerceIn(0, right.height - panelH)
        val l = Bitmap.createBitmap(left, baseLX, baseLY, panelW, panelH)
        val r = Bitmap.createBitmap(right, baseRX, baseRY, panelW, panelH)
        return Bitmap.createBitmap(panelW * 2, panelH, Bitmap.Config.ARGB_8888).also {
            val canvas = Canvas(it)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(l, 0f, 0f, paint)
            canvas.drawBitmap(r, panelW.toFloat(), 0f, paint)
        }
    }

    fun save(context: Context, bitmap: Bitmap): Uri {
        val name = "StereoGuide_${System.currentTimeMillis()}_SBS.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/StereoGuide")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Galeri kaydı oluşturulamadı")
        context.contentResolver.openOutputStream(uri).use {
            checkNotNull(it)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 96, it)
        }
        return uri
    }
}
