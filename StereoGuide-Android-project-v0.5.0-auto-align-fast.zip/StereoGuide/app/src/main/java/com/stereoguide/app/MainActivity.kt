package com.stereoguide.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.stereoguide.app.databinding.ActivityMainBinding
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var executor: ExecutorService
    private lateinit var tracker: OrientationTracker
    private lateinit var analyzer: FrameAlignmentAnalyzer
    private var imageCapture: ImageCapture? = null
    private var firstFile: File? = null
    private var firstPitch = 0f
    private var firstRoll = 0f
    private var pitch = 0f
    private var roll = 0f
    private var targetCm = 6
    private var targetShiftPixels = 7
    private var currentHorizontalError = 1f
    private var lastAlignmentDx = 0
    private var lastAlignmentDy = 0
    private var automaticCaptureRunning = false

    private val permission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else Toast.makeText(this, R.string.camera_permission, Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.controls) { view, insets ->
            val bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            view.setPadding(view.paddingLeft, view.paddingTop, view.paddingRight, bottom + dp(12))
            insets
        }
        executor = Executors.newSingleThreadExecutor()
        analyzer = FrameAlignmentAnalyzer { dx, dy ->
            runOnUiThread { updateVisualAlignment(dx, dy) }
        }

        tracker = OrientationTracker(this) { p, r ->
            pitch = p
            roll = r
            runOnUiThread {
                if (firstFile != null) {
                    binding.guide.pitchDelta = pitch - firstPitch
                    binding.guide.rollDelta = roll - firstRoll
                }
            }
        }

        binding.distanceGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked || firstFile != null) return@addOnButtonCheckedListener
            targetCm = when (checkedId) {
                R.id.close -> 4
                R.id.landscape -> 8
                else -> 6
            }
            targetShiftPixels = when (checkedId) {
                R.id.close -> 10
                R.id.landscape -> 5
                else -> 7
            }
        }
        binding.shutter.setOnClickListener { capture() }
        binding.reset.setOnClickListener { reset() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) startCamera() else permission.launch(Manifest.permission.CAMERA)
    }

    override fun onResume() {
        super.onResume()
        tracker.start()
    }

    override fun onPause() {
        tracker.stop()
        super.onPause()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder()
                .setTargetAspectRatio(androidx.camera.core.AspectRatio.RATIO_16_9)
                .build().also { it.surfaceProvider = binding.preview.surfaceProvider }
            imageCapture = ImageCapture.Builder()
                // Hareketli öznelerde iki çekim arasını mümkün olduğunca kısalt.
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setTargetAspectRatio(androidx.camera.core.AspectRatio.RATIO_16_9)
                .build()
            val analysis = ImageAnalysis.Builder()
                .setTargetAspectRatio(androidx.camera.core.AspectRatio.RATIO_16_9)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build().also { it.setAnalyzer(executor, analyzer) }
            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                imageCapture,
                analysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun capture() {
        if (firstFile != null && !automaticCaptureRunning) return
        val capture = imageCapture ?: return
        val file = File.createTempFile("stereo_", ".jpg", cacheDir)
        val output = ImageCapture.OutputFileOptions.Builder(file).build()
        binding.shutter.isEnabled = false
        capture.takePicture(output, executor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                runOnUiThread {
                    binding.shutter.isEnabled = true
                    if (firstFile == null) acceptFirst(file) else acceptSecond(file)
                }
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread {
                    binding.shutter.isEnabled = true
                    Toast.makeText(this@MainActivity, exception.message, Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun acceptFirst(file: File) {
        firstFile = file
        firstPitch = pitch
        firstRoll = roll
        analyzer.requestReference()
        // Kullanıcıdan manuel üst üste bindirme beklemiyoruz. Canlı analiz ve
        // sonradan kırpma/döndürme işlemlerini uygulama yapar.
        binding.ghost.visibility = android.view.View.GONE
        binding.guide.secondShot = true
        binding.distanceGroup.isEnabled = false
        binding.shutter.visibility = android.view.View.INVISIBLE
        binding.status.text = getString(R.string.second_photo, targetCm)
        vibrate()
    }

    private fun acceptSecond(file: File) {
        val left = firstFile ?: return
        try {
            val sbs = StereoComposer.makeSbs16x9(
                left,
                file,
                roll - firstRoll,
                lastAlignmentDx,
                lastAlignmentDy,
                analyzer.analysisWidth,
                analyzer.analysisHeight
            )
            StereoComposer.save(this, sbs)
            Toast.makeText(this, R.string.saved, Toast.LENGTH_LONG).show()
            vibrate()
            reset()
        } catch (error: Throwable) {
            Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()
            reset()
        } finally {
            file.delete()
        }
    }

    private fun reset() {
        firstFile?.delete()
        firstFile = null
        analyzer.clearReference()
        automaticCaptureRunning = false
        lastAlignmentDx = 0
        lastAlignmentDy = 0
        currentHorizontalError = 1f
        binding.ghost.setImageDrawable(null)
        binding.ghost.visibility = android.view.View.GONE
        binding.guide.secondShot = false
        binding.guide.pitchDelta = 0f
        binding.guide.rollDelta = 0f
        binding.guide.horizontalError = 1f
        binding.guide.verticalError = 0f
        binding.guide.stabilityProgress = 0f
        binding.distanceGroup.isEnabled = true
        binding.shutter.visibility = android.view.View.VISIBLE
        binding.shutter.isEnabled = true
        binding.status.setText(R.string.first_photo)
    }

    private fun updateVisualAlignment(dx: Int, dy: Int) {
        if (firstFile == null || automaticCaptureRunning) return
        // Telefon sağa giderken sahne canlı karede sola kayar; bu yüzden hedef negatiftir.
        val targetDx = -targetShiftPixels
        currentHorizontalError = (dx - targetDx).toFloat() / targetShiftPixels
        lastAlignmentDx = dx
        lastAlignmentDy = dy
        binding.guide.horizontalError = currentHorizontalError
        binding.guide.verticalError = dy / 10f

        // Sağa doğru yeterli hareket gerçekleşir gerçekleşmez çek. Tilt ve
        // dikey sapma kullanıcıyı bekletmez; besteci bunları sonradan düzeltir.
        val reached = dx <= targetDx + 2
        if (!reached) {
            binding.guide.stabilityProgress = 0f
            binding.status.setText(
                if (currentHorizontalError > 0f) R.string.move_right else R.string.move_left
            )
            return
        }

        binding.guide.stabilityProgress = 1f
        binding.status.setText(R.string.automatic_capture)
        automaticCaptureRunning = true
        capture()
    }

    private fun vibrate() {
        getSystemService<Vibrator>()?.vibrate(
            VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE)
        )
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
