package com.stereoguide.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class GuideOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = resources.displayMetrics.density * 2f
        style = Paint.Style.STROKE
    }
    var rollDelta = 0f
        set(value) { field = value; invalidate() }
    var pitchDelta = 0f
        set(value) { field = value; invalidate() }
    var horizontalError = 1f
        set(value) { field = value; invalidate() }
    var verticalError = 0f
        set(value) { field = value; invalidate() }
    var stabilityProgress = 0f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }
    var secondShot = false
        set(value) { field = value; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        paint.color = Color.rgb(53, 208, 127)
        canvas.drawLine(cx - 90f, cy, cx + 90f, cy, paint)
        canvas.drawLine(cx, cy - 90f, cx, cy + 90f, paint)
        canvas.drawCircle(cx, cy, 34f, paint)
        if (secondShot) {
            drawMovementArrow(canvas)
            paint.strokeWidth = resources.displayMetrics.density * 7f
            paint.color = Color.argb(210, 255, 255, 255)
            canvas.drawArc(
                cx - 52f, cy - 52f, cx + 52f, cy + 52f,
                -90f, 360f * stabilityProgress, false, paint
            )
            paint.strokeWidth = resources.displayMetrics.density * 2f
        }
    }

    private fun drawMovementArrow(canvas: Canvas) {
        val cy = height * .72f
        val goRight = horizontalError > 0f
        val start = if (goRight) width * .24f else width * .76f
        val end = if (goRight) width * .76f else width * .24f
        paint.color = if (horizontalError <= 0f) {
            Color.rgb(53, 208, 127)
        } else {
            Color.rgb(255, 138, 0)
        }
        paint.strokeWidth = resources.displayMetrics.density * 9f
        canvas.drawLine(start, cy, end, cy, paint)
        val direction = if (goRight) 1f else -1f
        canvas.drawLine(end, cy, end - direction * 42f, cy - 34f, paint)
        canvas.drawLine(end, cy, end - direction * 42f, cy + 34f, paint)

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = resources.displayMetrics.scaledDensity * 25f
        paint.isFakeBoldText = true
        val label = if (goRight) "TELEFONU SAĞA KAYDIR" else "BİRAZ GERİ GEL"
        val box = RectF(width * .14f, cy - 92f, width * .86f, cy - 48f)
        paint.color = Color.argb(195, 0, 0, 0)
        canvas.drawRoundRect(box, 18f, 18f, paint)
        paint.color = if (horizontalError <= 0f) Color.rgb(53, 208, 127) else Color.WHITE
        canvas.drawText(label, cx, cy - 60f, paint)
        paint.isFakeBoldText = false
        paint.style = Paint.Style.STROKE
    }
}
