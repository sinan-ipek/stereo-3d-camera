package com.stereoguide.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.PI

class OrientationTracker(
    context: Context,
    private val onChanged: (pitch: Float, roll: Float) -> Unit
) : SensorEventListener {
    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotation = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val matrix = FloatArray(9)
    private val orientation = FloatArray(3)

    fun start() = rotation?.let {
        manager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
    }
    fun stop() = manager.unregisterListener(this)

    override fun onSensorChanged(event: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(matrix, event.values)
        SensorManager.getOrientation(matrix, orientation)
        val degrees = (180f / PI.toFloat())
        onChanged(orientation[1] * degrees, orientation[2] * degrees)
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
